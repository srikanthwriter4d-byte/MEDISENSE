import React, { useRef, useEffect } from "react";

const URGENCY_CONFIG = {
  home_care: { label: "Home Care", color: "bg-green-100 text-green-700", dot: "bg-green-500" },
  see_doctor: { label: "See a Doctor", color: "bg-amber-100 text-amber-700", dot: "bg-amber-500" },
  go_to_er: { label: "Go to ER Now", color: "bg-red-100 text-red-700", dot: "bg-red-500" },
};

function TypingIndicator() {
  return (
    <div className="flex gap-3 mb-4">
      <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
        <span className="text-white text-xs font-bold">M</span>
      </div>
      <div className="bg-white border border-gray-100 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
        <div className="flex gap-1 items-center h-4">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function TriageResult({ result }) {
  if (!result) return null;
  const urgencyKey = result.urgency || "home_care";
  const cfg = URGENCY_CONFIG[urgencyKey] || URGENCY_CONFIG.home_care;

  return (
    <div className="mt-3 bg-gray-50 border border-gray-200 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${cfg.color}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
          {cfg.label}
        </span>
        <span className="text-xs text-gray-500">{result.urgency_reason}</span>
      </div>

      {result.symptoms_extracted?.length > 0 && (
        <div>
          <p className="text-xs font-medium text-gray-500 mb-1">Symptoms identified</p>
          <div className="flex flex-wrap gap-1">
            {result.symptoms_extracted.map((s, i) => (
              <span key={i} className="px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded-full">
                {s}
              </span>
            ))}
          </div>
        </div>
      )}

      {result.possible_conditions?.length > 0 && (
        <div>
          <p className="text-xs font-medium text-gray-500 mb-2">Possible conditions</p>
          <div className="space-y-1.5">
            {result.possible_conditions.map((c, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs font-medium text-gray-700">{c.name}</span>
                    <span className="text-xs text-gray-500">{Math.round(c.confidence * 100)}%</span>
                  </div>
                  <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 rounded-full transition-all"
                      style={{ width: `${c.confidence * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {result.next_steps?.length > 0 && (
        <div>
          <p className="text-xs font-medium text-gray-500 mb-1">Next steps</p>
          <ul className="space-y-0.5">
            {result.next_steps.map((step, i) => (
              <li key={i} className="text-xs text-gray-600 flex gap-1.5">
                <span className="text-blue-400 mt-0.5">→</span>
                {step}
              </li>
            ))}
          </ul>
        </div>
      )}

      {result.disclaimer && (
        <p className="text-xs text-gray-400 italic border-t border-gray-200 pt-2">{result.disclaimer}</p>
      )}
    </div>
  );
}

export default function ChatWindow({ messages, loading, lastResult }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
        <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-4">
          <span className="text-3xl">🩺</span>
        </div>
        <h3 className="font-semibold text-gray-700 mb-2">Describe your symptoms</h3>
        <p className="text-sm text-gray-400 max-w-xs">
          Tell me how you're feeling in plain language. I'll help assess the situation and guide you on next steps.
        </p>
        <div className="mt-6 grid grid-cols-2 gap-2 w-full max-w-xs">
          {["I have a bad headache and fever", "My chest feels tight", "I've had a sore throat for 3 days", "I feel dizzy and nauseous"].map((s, i) => (
            <div key={i} className="text-xs text-gray-500 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 cursor-default">
              "{s}"
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-1 scrollbar-thin">
      {messages.map((msg, i) => (
        <div key={i}>
          {msg.role === "user" ? (
            <div className="flex justify-end mb-4">
              <div className="max-w-xs lg:max-w-md bg-blue-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 text-sm shadow-sm">
                {msg.content}
              </div>
            </div>
          ) : (
            <div className="flex gap-3 mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-white text-xs font-bold">M</span>
              </div>
              <div className="max-w-xs lg:max-w-lg">
                <div className="bg-white border border-gray-100 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm text-sm text-gray-700">
                  {msg.content}
                </div>
                {i === messages.length - 1 && lastResult && (
                  <TriageResult result={lastResult} />
                )}
              </div>
            </div>
          )}
        </div>
      ))}
      {loading && <TypingIndicator />}
      <div ref={bottomRef} />
    </div>
  );
}
