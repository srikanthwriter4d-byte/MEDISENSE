import React, { useState } from "react";
import axios from "axios";

const COUNTRIES = [
  "India", "US", "USA", "UK", "Canada", "Australia",
  "Germany", "France", "Brazil", "Other"
];

export default function EligibilityGate({ onResult }) {
  const [age, setAge] = useState("");
  const [country, setCountry] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    if (!age || !country) {
      setError("Please fill in all fields.");
      return;
    }
    if (parseInt(age) < 1 || parseInt(age) > 120) {
      setError("Please enter a valid age.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const res = await axios.post("/api/eligibility", {
        age: parseInt(age),
        country,
      });
      onResult(res.data);
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="max-w-sm w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-200">
            <span className="text-white text-2xl font-bold">M</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">MediSense AI</h1>
          <p className="text-gray-500 text-sm mt-1">Intelligent symptom triage assistant</p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="font-semibold text-gray-800 mb-4">Before we begin</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Your Age</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="e.g. 28"
                className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
              >
                <option value="">Select your country</option>
                {COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            {error && (
              <p className="text-red-500 text-xs bg-red-50 px-3 py-2 rounded-lg">{error}</p>
            )}

            <button
              onClick={handleSubmit}
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-medium py-3 rounded-xl transition-colors text-sm"
            >
              {loading ? "Checking..." : "Continue →"}
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-gray-400 mt-4">
          Your data is not stored or shared. For informational purposes only.
        </p>
      </div>
    </div>
  );
}
