import React, { useState, useCallback } from "react";
import axios from "axios";
import ChatWindow from "../components/ChatWindow";
import ChatInput from "../components/ChatInput";

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [sessionId, setSessionId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [lastResult, setLastResult] = useState(null);
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [error, setError] = useState("");

  const handleSend = useCallback(async (text) => {
    setError("");
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setLoading(true);

    try {
      const payload = {
        message: text,
        session_id: sessionId || undefined,
        age: age ? parseInt(age) : undefined,
        gender: gender || undefined,
      };

      const res = await axios.post("/api/analyze", payload);
      const { session_id, result, history } = res.data;

      setSessionId(session_id);
      setLastResult(result);

      const followUp = result.follow_up_question;
      if (followUp) {
        setMessages((prev) => [...prev, { role: "assistant", content: followUp }]);
      } else {
        setMessages((prev) => [...prev, { role: "assistant", content: "Here's my assessment based on what you've shared." }]);
      }
    } catch (err) {
      setError("Failed to reach the server. Make sure the backend is running.");
      setMessages((prev) => prev.slice(0, -1));
    } finally {
      setLoading(false);
    }
  }, [sessionId, age, gender]);

  const handleReset = () => {
    setMessages([]);
    setSessionId(null);
    setLastResult(null);
    setError("");
  };

  const handleDownloadPDF = async () => {
    if (!sessionId) return;
    try {
      const res = await axios.get(`/api/report/${sessionId}`, { responseType: "blob" });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const a = document.createElement("a");
      a.href = url;
      a.download = `triage_${sessionId.slice(0, 8)}.pdf`;
      a.click();
    } catch {
      setError("Could not generate PDF. Try again.");
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col" style={{ height: "80vh" }}>
        {/* Top bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="flex gap-2 items-center">
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="Age"
                className="w-16 border border-gray-200 rounded-lg px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="border border-gray-200 rounded-lg px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
              >
                <option value="">Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            {sessionId && (
              <span className="text-xs text-gray-400">Session: {sessionId.slice(0, 8)}…</span>
            )}
          </div>
          <div className="flex gap-2">
            {sessionId && (
              <button
                onClick={handleDownloadPDF}
                className="text-xs px-3 py-1.5 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors"
              >
                ↓ PDF Report
              </button>
            )}
            <button
              onClick={handleReset}
              className="text-xs px-3 py-1.5 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors"
            >
              New Chat
            </button>
          </div>
        </div>

        {error && (
          <div className="mx-4 mt-3 px-3 py-2 bg-red-50 border border-red-100 rounded-lg text-xs text-red-600">
            {error}
          </div>
        )}

        <ChatWindow messages={messages} loading={loading} lastResult={lastResult} />
        <ChatInput onSend={handleSend} loading={loading} disabled={false} />
      </div>
    </div>
  );
}
