import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";

const URGENCY_COLORS = {
  home_care: "#059669",
  see_doctor: "#d97706",
  go_to_er: "#dc2626",
};

const URGENCY_LABELS = {
  home_care: "Home Care",
  see_doctor: "See Doctor",
  go_to_er: "ER Now",
};

function StatCard({ label, value, sub, color = "blue" }) {
  const colors = {
    blue: "bg-blue-50 text-blue-700",
    green: "bg-green-50 text-green-700",
    amber: "bg-amber-50 text-amber-700",
    red: "bg-red-50 text-red-700",
  };
  return (
    <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
      <p className="text-xs text-gray-500 mb-1">{label}</p>
      <p className={`text-2xl font-bold ${colors[color].split(" ")[1]}`}>{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
    </div>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      axios.get("/api/stats"),
      axios.get("/api/sessions"),
    ]).then(([statsRes, sessionsRes]) => {
      setStats(statsRes.data);
      setSessions(sessionsRes.data);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-12 text-center">
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-sm text-gray-400 mt-3">Loading dashboard...</p>
      </div>
    );
  }

  const urgencyData = stats
    ? Object.entries(stats.urgency_distribution).map(([k, v]) => ({
        name: URGENCY_LABELS[k] || k,
        value: v,
        color: URGENCY_COLORS[k] || "#6b7280",
      }))
    : [];

  const topUrgency = urgencyData.sort((a, b) => b.value - a.value)[0];

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      <h2 className="text-lg font-semibold text-gray-800">Analytics Dashboard</h2>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total Sessions" value={stats?.total_sessions || 0} color="blue" />
        <StatCard
          label="Home Care"
          value={stats?.urgency_distribution?.home_care || 0}
          sub="patients"
          color="green"
        />
        <StatCard
          label="See Doctor"
          value={stats?.urgency_distribution?.see_doctor || 0}
          sub="patients"
          color="amber"
        />
        <StatCard
          label="ER Referrals"
          value={stats?.urgency_distribution?.go_to_er || 0}
          sub="patients"
          color="red"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Top symptoms bar chart */}
        <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
          <h3 className="text-sm font-medium text-gray-700 mb-4">Top Symptoms</h3>
          {stats?.top_symptoms?.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={stats.top_symptoms} layout="vertical" margin={{ left: 20, right: 10 }}>
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="symptom" tick={{ fontSize: 11 }} width={90} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">
              No data yet. Run some symptom checks first.
            </div>
          )}
        </div>

        {/* Urgency pie chart */}
        <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
          <h3 className="text-sm font-medium text-gray-700 mb-4">Urgency Distribution</h3>
          {urgencyData.some((d) => d.value > 0) ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={urgencyData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {urgencyData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Legend formatter={(value) => <span style={{ fontSize: 11 }}>{value}</span>} />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400 text-sm">
              No data yet.
            </div>
          )}
        </div>
      </div>

      {/* Recent sessions */}
      <div className="bg-white border border-gray-100 rounded-xl shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100">
          <h3 className="text-sm font-medium text-gray-700">Recent Sessions</h3>
        </div>
        {sessions.length === 0 ? (
          <div className="p-8 text-center text-sm text-gray-400">No sessions yet.</div>
        ) : (
          <div className="divide-y divide-gray-50">
            {sessions.slice(0, 10).map((s) => {
              const urgency = s.last_result?.urgency;
              const cfg = urgency ? {
                home_care: "bg-green-100 text-green-700",
                see_doctor: "bg-amber-100 text-amber-700",
                go_to_er: "bg-red-100 text-red-700",
              }[urgency] : "bg-gray-100 text-gray-500";
              const label = urgency ? URGENCY_LABELS[urgency] : "—";
              const symptoms = s.last_result?.symptoms_extracted?.slice(0, 3).join(", ") || "—";

              return (
                <div key={s.session_id} className="px-4 py-3 flex items-center gap-4 hover:bg-gray-50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-400 font-mono">{s.session_id.slice(0, 12)}…</p>
                    <p className="text-sm text-gray-700 truncate">{symptoms}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium whitespace-nowrap ${cfg}`}>{label}</span>
                  <p className="text-xs text-gray-400 whitespace-nowrap">
                    {new Date(s.updated_at).toLocaleDateString()}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
