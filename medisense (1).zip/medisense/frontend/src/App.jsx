import React, { useState } from "react";
import EligibilityGate from "./components/EligibilityGate";
import ChatPage from "./pages/ChatPage";
import DashboardPage from "./pages/DashboardPage";
import "./App.css";

export default function App() {
  const [eligible, setEligible] = useState(null);
  const [page, setPage] = useState("chat");
  const [googleFormUrl, setGoogleFormUrl] = useState(null);

  const handleEligibility = (result) => {
    setEligible(result.eligible);
    if (!result.eligible) setGoogleFormUrl(result.google_form_url);
  };

  if (eligible === null) {
    return <EligibilityGate onResult={handleEligibility} />;
  }

  if (!eligible) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-8">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-sm border border-gray-100 p-8 text-center">
          <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">📋</span>
          </div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Not Yet Available</h2>
          <p className="text-gray-500 text-sm mb-6">
            MediSense isn't available in your region or for your age group yet — but we'd love to hear from you.
          </p>
          <a
            href={googleFormUrl || "https://forms.google.com"}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-xl transition-colors"
          >
            Submit via Google Form →
          </a>
          <button
            onClick={() => setEligible(null)}
            className="mt-3 text-sm text-gray-400 hover:text-gray-600 underline"
          >
            Go back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white text-sm font-bold">M</span>
          </div>
          <span className="font-semibold text-gray-800 text-lg">MediSense AI</span>
          <span className="ml-2 px-2 py-0.5 bg-blue-50 text-blue-600 text-xs rounded-full font-medium">Beta</span>
        </div>
        <div className="flex gap-1">
          <button
            onClick={() => setPage("chat")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              page === "chat" ? "bg-blue-50 text-blue-600" : "text-gray-500 hover:text-gray-700"
            }`}
          >
            Symptom Check
          </button>
          <button
            onClick={() => setPage("dashboard")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              page === "dashboard" ? "bg-blue-50 text-blue-600" : "text-gray-500 hover:text-gray-700"
            }`}
          >
            Dashboard
          </button>
        </div>
      </nav>

      {page === "chat" ? <ChatPage /> : <DashboardPage />}

      <footer className="text-center py-6 text-xs text-gray-400">
        MediSense AI is not a substitute for professional medical advice. Always consult a licensed doctor.
      </footer>
    </div>
  );
}
