from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import uvicorn
import uuid

from ai_engine import analyze_symptoms
from database import init_db, save_session, get_session, get_all_sessions
from pdf_export import generate_pdf

app = FastAPI(title="MediSense AI", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()


class MessageRequest(BaseModel):
    session_id: Optional[str] = None
    message: str
    age: Optional[int] = None
    gender: Optional[str] = None


class EligibilityRequest(BaseModel):
    age: int
    country: str


@app.get("/")
def root():
    return {"status": "MediSense AI running"}


@app.post("/api/analyze")
async def analyze(req: MessageRequest):
    session_id = req.session_id or str(uuid.uuid4())
    session = get_session(session_id)

    history = session.get("history", []) if session else []
    patient_info = session.get("patient_info", {}) if session else {}

    if req.age:
        patient_info["age"] = req.age
    if req.gender:
        patient_info["gender"] = req.gender

    history.append({"role": "user", "content": req.message})

    result = await analyze_symptoms(history, patient_info)

    history.append({"role": "assistant", "content": result.get("follow_up_question", "")})

    save_session(session_id, history, patient_info, result)

    return {
        "session_id": session_id,
        "result": result,
        "history": history,
    }


@app.get("/api/session/{session_id}")
def get_session_data(session_id: str):
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@app.get("/api/sessions")
def list_sessions():
    return get_all_sessions()


@app.get("/api/report/{session_id}")
def download_report(session_id: str):
    from fastapi.responses import FileResponse
    session = get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    pdf_path = generate_pdf(session_id, session)
    return FileResponse(pdf_path, media_type="application/pdf", filename=f"triage_{session_id[:8]}.pdf")


@app.post("/api/eligibility")
def check_eligibility(req: EligibilityRequest):
    eligible = req.age >= 18 and req.country.lower() in [
        "india", "us", "usa", "uk", "canada", "australia"
    ]
    return {
        "eligible": eligible,
        "google_form_url": "https://forms.google.com/your-form-id" if not eligible else None,
        "reason": None if eligible else "Service not available in your region or for minors. Please use the form below."
    }


@app.get("/api/stats")
def get_stats():
    sessions = get_all_sessions()
    symptom_counts = {}
    urgency_counts = {"home_care": 0, "see_doctor": 0, "go_to_er": 0}

    for s in sessions:
        result = s.get("last_result", {})
        for sym in result.get("symptoms_extracted", []):
            symptom_counts[sym] = symptom_counts.get(sym, 0) + 1
        urgency = result.get("urgency")
        if urgency in urgency_counts:
            urgency_counts[urgency] += 1

    top_symptoms = sorted(symptom_counts.items(), key=lambda x: x[1], reverse=True)[:8]
    return {
        "total_sessions": len(sessions),
        "urgency_distribution": urgency_counts,
        "top_symptoms": [{"symptom": k, "count": v} for k, v in top_symptoms],
    }


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
