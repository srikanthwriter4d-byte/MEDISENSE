import sqlite3
import json
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "medisense.db")


def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT PRIMARY KEY,
            history TEXT,
            patient_info TEXT,
            last_result TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    conn.commit()
    conn.close()


def save_session(session_id: str, history: list, patient_info: dict, last_result: dict):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    now = datetime.utcnow().isoformat()

    existing = c.execute(
        "SELECT session_id FROM sessions WHERE session_id = ?", (session_id,)
    ).fetchone()

    if existing:
        c.execute(
            """UPDATE sessions SET history=?, patient_info=?, last_result=?, updated_at=?
               WHERE session_id=?""",
            (
                json.dumps(history),
                json.dumps(patient_info),
                json.dumps(last_result),
                now,
                session_id,
            ),
        )
    else:
        c.execute(
            """INSERT INTO sessions (session_id, history, patient_info, last_result, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                session_id,
                json.dumps(history),
                json.dumps(patient_info),
                json.dumps(last_result),
                now,
                now,
            ),
        )

    conn.commit()
    conn.close()


def get_session(session_id: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    row = c.execute(
        "SELECT history, patient_info, last_result, created_at, updated_at FROM sessions WHERE session_id=?",
        (session_id,),
    ).fetchone()
    conn.close()

    if not row:
        return None

    return {
        "session_id": session_id,
        "history": json.loads(row[0]),
        "patient_info": json.loads(row[1]),
        "last_result": json.loads(row[2]),
        "created_at": row[3],
        "updated_at": row[4],
    }


def get_all_sessions():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    rows = c.execute(
        "SELECT session_id, history, patient_info, last_result, created_at, updated_at FROM sessions ORDER BY updated_at DESC"
    ).fetchall()
    conn.close()

    sessions = []
    for row in rows:
        sessions.append({
            "session_id": row[0],
            "history": json.loads(row[1]),
            "patient_info": json.loads(row[2]),
            "last_result": json.loads(row[3]),
            "created_at": row[4],
            "updated_at": row[5],
        })
    return sessions
