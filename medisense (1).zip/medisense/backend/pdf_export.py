import os
from datetime import datetime

REPORTS_DIR = os.path.join(os.path.dirname(__file__), "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)


def generate_pdf(session_id: str, session: dict) -> str:
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
        from reportlab.lib.enums import TA_CENTER, TA_LEFT
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    pdf_path = os.path.join(REPORTS_DIR, f"triage_{session_id[:8]}.pdf")
    doc = SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("title", fontSize=22, fontName="Helvetica-Bold", textColor=colors.HexColor("#1a1a2e"), alignment=TA_CENTER, spaceAfter=6)
    subtitle_style = ParagraphStyle("subtitle", fontSize=11, fontName="Helvetica", textColor=colors.HexColor("#6b7280"), alignment=TA_CENTER, spaceAfter=20)
    section_style = ParagraphStyle("section", fontSize=13, fontName="Helvetica-Bold", textColor=colors.HexColor("#1a1a2e"), spaceBefore=16, spaceAfter=8)
    body_style = ParagraphStyle("body", fontSize=10, fontName="Helvetica", textColor=colors.HexColor("#374151"), spaceAfter=4, leading=16)
    disclaimer_style = ParagraphStyle("disclaimer", fontSize=9, fontName="Helvetica-Oblique", textColor=colors.HexColor("#9ca3af"), alignment=TA_CENTER, spaceBefore=20)

    result = session.get("last_result", {})
    patient_info = session.get("patient_info", {})
    history = session.get("history", [])

    urgency = result.get("urgency", "unknown")
    urgency_colors = {
        "home_care": colors.HexColor("#059669"),
        "see_doctor": colors.HexColor("#d97706"),
        "go_to_er": colors.HexColor("#dc2626"),
    }
    urgency_labels = {
        "home_care": "HOME CARE",
        "see_doctor": "SEE A DOCTOR",
        "go_to_er": "GO TO ER NOW",
    }
    urgency_color = urgency_colors.get(urgency, colors.gray)
    urgency_label = urgency_labels.get(urgency, urgency.upper())

    story = []

    story.append(Paragraph("MediSense AI", title_style))
    story.append(Paragraph("Symptom Triage Report", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#e5e7eb")))
    story.append(Spacer(1, 12))

    meta_data = [
        ["Session ID", session_id[:16] + "..."],
        ["Generated", datetime.utcnow().strftime("%B %d, %Y at %H:%M UTC")],
        ["Patient Age", str(patient_info.get("age", "Not provided"))],
        ["Patient Gender", str(patient_info.get("gender", "Not provided"))],
    ]
    meta_table = Table(meta_data, colWidths=[4*cm, 12*cm])
    meta_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (1, 0), (1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#6b7280")),
        ("TEXTCOLOR", (1, 0), (1, -1), colors.HexColor("#111827")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 16))

    urgency_table = Table([[f"  URGENCY LEVEL: {urgency_label}  "]], colWidths=[17*cm])
    urgency_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), urgency_color),
        ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 14),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, -1), 12),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 12),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    story.append(urgency_table)
    story.append(Spacer(1, 6))
    story.append(Paragraph(result.get("urgency_reason", ""), body_style))

    story.append(Paragraph("Symptoms Identified", section_style))
    symptoms = result.get("symptoms_extracted", [])
    if symptoms:
        story.append(Paragraph(" • " + "  •  ".join([s.title() for s in symptoms]), body_style))
    else:
        story.append(Paragraph("No symptoms extracted.", body_style))

    story.append(Paragraph("Possible Conditions", section_style))
    conditions = result.get("possible_conditions", [])
    if conditions:
        cond_data = [["Condition", "Confidence", "Description"]]
        for cond in conditions:
            conf_pct = f"{int(cond.get('confidence', 0) * 100)}%"
            cond_data.append([cond.get("name", ""), conf_pct, cond.get("description", "")])
        cond_table = Table(cond_data, colWidths=[4*cm, 2.5*cm, 10.5*cm])
        cond_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f3f4f6")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e5e7eb")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#fafafa")]),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(cond_table)

    story.append(Paragraph("Recommended Next Steps", section_style))
    for i, step in enumerate(result.get("next_steps", []), 1):
        story.append(Paragraph(f"{i}. {step}", body_style))

    story.append(Paragraph("Conversation Summary", section_style))
    user_messages = [m for m in history if m["role"] == "user"]
    for i, msg in enumerate(user_messages, 1):
        story.append(Paragraph(f"<b>Message {i}:</b> {msg['content']}", body_style))

    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#e5e7eb")))
    disclaimer = result.get("disclaimer", "This report is generated by an AI assistant and does not constitute medical advice. Always consult a licensed healthcare professional for diagnosis and treatment.")
    story.append(Paragraph(disclaimer, disclaimer_style))

    doc.build(story)
    return pdf_path
