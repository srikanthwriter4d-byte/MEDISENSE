import json
import re
import os

# ============================================================
# CHOOSE YOUR AI PROVIDER (set the one you want to use)
# ============================================================
# Options: "gemini" | "groq" | "claude"
PROVIDER = "gemini"

# ============================================================
# API KEYS — set via environment variable or paste directly
# ============================================================
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_GEMINI_API_KEY_HERE")    # Free: aistudio.google.com
GROQ_API_KEY   = os.getenv("GROQ_API_KEY",   "YOUR_GROQ_API_KEY_HERE")      # Free: console.groq.com
CLAUDE_API_KEY = os.getenv("ANTHROPIC_API_KEY", "YOUR_CLAUDE_API_KEY_HERE") # Paid: console.anthropic.com

# ============================================================
SYSTEM_PROMPT = """You are MediSense, an expert medical triage assistant.
Your role is to help users understand their symptoms and determine urgency of care needed.

Given a patient's conversation history and optional patient info, respond ONLY with a valid JSON object.

IMPORTANT RULES:
- Never diagnose definitively. Use language like "possibly", "may indicate"
- Always recommend professional medical consultation
- If symptoms suggest emergency (chest pain, difficulty breathing, stroke signs), urgency MUST be "go_to_er"
- Be empathetic and clear

Return ONLY this JSON (no markdown, no extra text):
{
  "symptoms_extracted": ["list", "of", "symptoms"],
  "possible_conditions": [
    {
      "name": "Condition Name",
      "confidence": 0.85,
      "description": "Brief 1-sentence description"
    }
  ],
  "urgency": "home_care",
  "urgency_reason": "Why this urgency level was chosen",
  "next_steps": ["Step 1", "Step 2", "Step 3"],
  "follow_up_question": "One clarifying question to ask next, or empty string if enough info",
  "disclaimer": "This is not a medical diagnosis. Please consult a healthcare professional."
}

urgency values: "home_care" | "see_doctor" | "go_to_er"
confidence values: 0.0 to 1.0
possible_conditions: 2-4 conditions maximum
"""


def _clean_json(raw: str) -> dict:
    raw = re.sub(r"^```json\s*", "", raw.strip())
    raw = re.sub(r"\s*```$", "", raw)
    return json.loads(raw.strip())


def _build_messages(history: list, patient_info: dict) -> list:
    patient_context = ""
    if patient_info:
        parts = []
        if "age" in patient_info:
            parts.append(f"Age: {patient_info['age']}")
        if "gender" in patient_info:
            parts.append(f"Gender: {patient_info['gender']}")
        if parts:
            patient_context = f"Patient info: {', '.join(parts)}\n\n"

    messages = []
    for msg in history:
        if msg["role"] == "user":
            messages.append({"role": "user", "content": msg["content"]})
        elif msg["role"] == "assistant" and msg["content"]:
            messages.append({"role": "assistant", "content": msg["content"]})

    if patient_context and messages:
        messages[0]["content"] = patient_context + messages[0]["content"]

    if not messages:
        messages = [{"role": "user", "content": "Hello"}]

    return messages


# ------------------------------------------------------------
# GEMINI (Free — recommended for hackathon)
# Get key at: https://aistudio.google.com
# pip install google-generativeai
# ------------------------------------------------------------
async def _analyze_gemini(history: list, patient_info: dict) -> dict:
    import google.generativeai as genai
    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel(
        model_name="gemini-1.5-flash",
        system_instruction=SYSTEM_PROMPT,
    )
    messages = _build_messages(history, patient_info)
    last_user_msg = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "Hello")
    response = model.generate_content(last_user_msg)
    return _clean_json(response.text)


# ------------------------------------------------------------
# GROQ (Free — fastest responses)
# Get key at: https://console.groq.com
# pip install groq
# ------------------------------------------------------------
async def _analyze_groq(history: list, patient_info: dict) -> dict:
    from groq import Groq
    client = Groq(api_key=GROQ_API_KEY)
    messages = _build_messages(history, patient_info)
    response = client.chat.completions.create(
        model="llama3-8b-8192",
        messages=[{"role": "system", "content": SYSTEM_PROMPT}] + messages,
        max_tokens=1500,
    )
    return _clean_json(response.choices[0].message.content)


# ------------------------------------------------------------
# CLAUDE (Paid — highest quality)
# Get key at: https://console.anthropic.com
# pip install anthropic
# ------------------------------------------------------------
async def _analyze_claude(history: list, patient_info: dict) -> dict:
    import anthropic
    client = anthropic.Anthropic(api_key=CLAUDE_API_KEY)
    messages = _build_messages(history, patient_info)
    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1500,
        system=SYSTEM_PROMPT,
        messages=messages,
    )
    return _clean_json(response.content[0].text)


# ------------------------------------------------------------
# Main entry point — routes to selected provider
# ------------------------------------------------------------
async def analyze_symptoms(history: list, patient_info: dict) -> dict:
    if PROVIDER == "gemini":
        return await _analyze_gemini(history, patient_info)
    elif PROVIDER == "groq":
        return await _analyze_groq(history, patient_info)
    elif PROVIDER == "claude":
        return await _analyze_claude(history, patient_info)
    else:
        raise ValueError(f"Unknown provider: {PROVIDER}. Choose 'gemini', 'groq', or 'claude'.")
