# MediSense AI 🩺

**AI-powered symptom triage assistant** — Full-stack health tech hackathon project.

Users describe symptoms in natural language. MediSense extracts symptoms, ranks possible conditions with confidence scores, assigns an urgency level (Home Care / See Doctor / ER Now), and generates downloadable PDF triage reports.

---

## Tech Stack

| Layer | Tech |
|---|---|
| Frontend | React 18, Tailwind CSS, Recharts |
| Backend | Python 3.11+, FastAPI, Pydantic |
| AI | Claude API (claude-opus-4-5) |
| Database | SQLite (zero config) |
| PDF | ReportLab |

---

## Project Structure

```
medisense/
├── backend/
│   ├── main.py           # FastAPI app, all routes
│   ├── ai_engine.py      # Claude API + structured JSON output
│   ├── database.py       # SQLite session storage
│   ├── pdf_export.py     # ReportLab PDF generation
│   └── requirements.txt
├── frontend/
│   ├── public/index.html
│   └── src/
│       ├── App.jsx                        # Root + routing
│       ├── components/
│       │   ├── EligibilityGate.jsx        # Age + country check → Google Form fallback
│       │   ├── ChatWindow.jsx             # Message thread + triage result card
│       │   └── ChatInput.jsx              # Textarea + send button
│       └── pages/
│           ├── ChatPage.jsx               # Main chat experience
│           └── DashboardPage.jsx          # Stats, charts, session history
└── README.md
```

---

## Setup

### 1. Backend

```bash
cd backend
pip install -r requirements.txt

# Set your Claude API key
export ANTHROPIC_API_KEY=sk-ant-...

python main.py
# → Runs at http://localhost:8000
```

### 2. Frontend

```bash
cd frontend
npm install
npm start
# → Runs at http://localhost:3000
```

---

## API Endpoints

| Method | Route | Description |
|---|---|---|
| POST | `/api/analyze` | Send symptom message, get AI triage result |
| GET | `/api/session/{id}` | Get full session data |
| GET | `/api/sessions` | List all sessions |
| GET | `/api/report/{id}` | Download PDF triage report |
| POST | `/api/eligibility` | Check if user is eligible |
| GET | `/api/stats` | Dashboard stats (symptom counts, urgency distribution) |

### Sample `/api/analyze` request

```json
{
  "message": "I have a severe headache, fever of 39°C, and stiff neck since yesterday",
  "age": 28,
  "gender": "female"
}
```

### Sample AI response structure

```json
{
  "symptoms_extracted": ["severe headache", "fever", "stiff neck"],
  "possible_conditions": [
    { "name": "Viral Meningitis", "confidence": 0.72, "description": "Inflammation of brain membranes" },
    { "name": "Severe Flu", "confidence": 0.55, "description": "Influenza with systemic symptoms" }
  ],
  "urgency": "go_to_er",
  "urgency_reason": "Combination of severe headache, high fever, and stiff neck requires immediate evaluation",
  "next_steps": ["Go to ER immediately", "Do not drive yourself", "Inform staff of all symptoms"],
  "follow_up_question": "Are you experiencing any sensitivity to light or sound?",
  "disclaimer": "This is not a medical diagnosis. Please consult a healthcare professional."
}
```

---

## Key Features

- **Multi-turn conversation** — follow-up questions refine the diagnosis
- **Eligibility gate** — age + country check with Google Form fallback for ineligible users
- **Urgency classification** — 3-tier system with color-coded badges
- **PDF report generation** — downloadable triage summary with ReportLab
- **Analytics dashboard** — symptom frequency charts, urgency distribution pie chart
- **Session persistence** — SQLite stores full conversation history

---

## Hackathon Pitch Points

1. **Real problem** — "Should I go to the ER?" is asked millions of times daily
2. **Explainable AI** — confidence scores + urgency reasoning, not a black box
3. **Inclusivity** — ineligible users get a Google Form path, no dead ends
4. **Roadmap** — telemedicine integration, hospital API, EHR export, multilingual support

---

## Disclaimer

MediSense AI is a prototype built for educational/hackathon purposes. It is **not** a licensed medical device and **must not** be used as a substitute for professional medical advice, diagnosis, or treatment.
